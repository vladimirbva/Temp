# Сцена «Комната» — ассеты (CC0)

31 модель из Kenney Furniture Kit v1.0 (CC0 1.0, public domain).
Целевая папка в проекте: `src/Yaseek.Api/wwwroot/assets/room/`
(при сборке попадают в PWA-кэш yaseek-v131+).

## Карта объекта сцены → модель
- Пол: floorFull (+ rugRound/rugRectangle — коврики)
- Стены: wall, wallCorner, wallWindow (окно — для световых уровней)
- Дверь: doorway
- Кроватка ребёнка: bedSingle + pillow/pillowBlue
- Игрушка-сосед: bear
- Кухня (кормление): kitchenCabinet, kitchenCabinetDrawer, kitchenFridgeSmall, kitchenSink, kitchenStove, kitchenCoffeeMachine
- Склад (шкаф с баночками): bookcaseOpenLow (полки видны) + bookcaseClosed
- Горшок/дефекация: toilet (горшок — примитивом поверх, для малыша)
- ИИ-доктор (уголок): laptop (+ pottedPlant, plantSmall1/2 для уюта)
- Статистика: table + books-стилистика (можно books из примитивов)
- Чат (телефон «звонит»): sideTable (телефон — примитивом)
- Настройки: sideTableDrawers
- Свет: lampRoundFloor (ночник), lampSquareCeiling (потолочный)

Модели low-poly, материалы с базовыми цветами — внешние текстуры не нужны (проверено:
images отсутствуют во всех файлах). Масштаб Kenney: 1 юнит = 1 м.
